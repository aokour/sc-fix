Installation instructions:

- Extract the 'SC Hotfix*.update' file from the 'SC Hotfix*.zip' package.
- Use the Update Installation Wizard to install the package.
- Run the SQL script CreateFilteredIndex.sql provided in the hotfix against master database.

Notes:
- Make sure the 'ContentSearch.Indexing.DisableDatabaseCaches' and 'Caching.DisableCacheSizeLimits' settings are disabled on the Indexing instance:
    <setting name="ContentSearch.Indexing.DisableDatabaseCaches" value="false"/>
    <setting name="Caching.DisableCacheSizeLimits" value="false" />

- Tune capacity of caches according to available memory and requirement regarding memory consumption

- As part of the fix for #177155 'LinkManager.GetItemUrl gets the wrong site' please add 'disableTrailingWildcard="true"' attribute to the site configuration under <sites> node for every site involved in the issue.

- Add the following setting to the Sitecore configuration:
    <setting name="ContentSearch.IndexingManager.DisplayShortStatistic" value="true" />
  It will eliminate requests to Solr which don't go through a load balancer. When the setting is enabled, the Indexing Manager Wizard will display only short statistic for indexes. 
